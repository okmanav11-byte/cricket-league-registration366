# Cricket League Registration — Netlify ready

Next.js App Router project with Supabase storage, Razorpay order creation/verification, UPI QR display, and a password-protected admin area.

## Deploy
1. Extract this ZIP on your computer/phone.
2. Import the extracted project folder into a GitHub repository (keep folders intact), then connect that repository to Netlify.
3. Netlify build command: `npm run build`. The included `netlify.toml` configures the Next.js adapter.
4. Add all values from `.env.example` in Netlify → Site configuration → Environment variables.
5. Run `supabase/schema.sql` in the Supabase SQL Editor.
6. Set Razorpay webhook URL to `https://YOUR-SITE.netlify.app/api/payments/webhook`.

## Local development
`npm install` then copy `.env.example` to `.env.local`, fill values, and run `npm run dev`.

## Important
- Never commit `.env.local` or any secret key to GitHub.
- Razorpay live payments require account activation and live API keys.
- UPI QR/manual UPI payments are displayed for reference; admin must verify them manually. Razorpay online payments are verified server-side.
- Set a strong `ADMIN_PASSWORD`. This starter uses a simple password gate; add stronger identity/access controls before production use.