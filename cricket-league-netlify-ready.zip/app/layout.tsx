import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Cricket League Registration", description: "Register for the cricket league" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}