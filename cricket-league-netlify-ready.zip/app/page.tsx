 "use client";
import {useEffect,useState} from "react";\nimport QRCode from "qrcode";
declare global {interface Window { Razorpay:any }}
type Settings={league_name:string;registration_fee:number;upi_id:string;payee_name:string;registration_open:boolean};
export default function Home(){
 const [s,setS]=useState<Settings|null>(null),[qr,setQr]=useState(""),[form,setForm]=useState({full_name:"",email:"",phone:"",team_name:"",player_role:"",city:""}),[msg,setMsg]=useState("");
 useEffect(()=>{fetch("/api/settings").then(r=>r.json()).then((v)=>{setS(v);if(v.upi_id){const link=`upi://pay?pa=${encodeURIComponent(v.upi_id)}&pn=${encodeURIComponent(v.payee_name||"Cricket League")}&am=${v.registration_fee}&cu=INR`;QRCode.toDataURL(link).then(setQr).catch(()=>{});}}).catch(()=>setMsg("Unable to load league settings."));},[]);
 function change(e:React.ChangeEvent<HTMLInputElement|HTMLSelectElement>){setForm({...form,[e.target.name]:e.target.value});}
 async function submit(e:React.FormEvent){e.preventDefault();setMsg("Creating registration…");
  const r=await fetch("/api/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});const d=await r.json();
  if(!r.ok){setMsg(d.error||"Registration failed");return;}
  if(!s){setMsg("Settings not loaded");return;}
  const order=await fetch("/api/payments/create-order",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({registrationId:d.id})});
  const od=await order.json(); if(!order.ok){setMsg(od.error||"Could not start payment");return;}
  const options={key:od.keyId,amount:od.amount,currency:"INR",name:s.league_name,description:"League registration",order_id:od.orderId,
   handler:async (response:any)=>{const vr=await fetch("/api/payments/verify",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...response,registrationId:d.id})});const vd=await vr.json();setMsg(vr.ok?"Payment verified! Registration complete.":(vd.error||"Payment verification failed"));},
   prefill:{name:form.full_name,email:form.email,contact:form.phone},theme:{color:"#1456c0"}};
  if(!window.Razorpay){const script=document.createElement("script");script.src="https://checkout.razorpay.com/v1/checkout.js";script.onload=()=>new window.Razorpay(options).open();document.body.appendChild(script);}else new window.Razorpay(options).open();
  setMsg("Complete payment in the secure Razorpay window.");
 }
 const upi=s?.upi_id?`upi://pay?pa=${encodeURIComponent(s.upi_id)}&pn=${encodeURIComponent(s.payee_name)}&am=${s.registration_fee}&cu=INR`:"";
 return <main><section className="panel"><h1>{s?.league_name||"Cricket League"}</h1><p className="muted">Player registration</p><h2>Registration fee: ₹{s?.registration_fee??"—"}</h2>{s&&!s.registration_open?<p>Registrations are currently closed.</p>:<form onSubmit={submit}><div className="grid">{(["full_name","email","phone","team_name","city"] as const).map(k=><div key={k}><label>{({full_name:"Full name",email:"Email",phone:"Phone",team_name:"Team name (optional)",city:"City"} as any)[k]}</label><input name={k} required={["full_name","email","phone"].includes(k)} value={form[k]} onChange={change}/></div>)}<div><label>Player role</label><select name="player_role" value={form.player_role} onChange={change}><option value="">Select role</option><option>Batter</option><option>Bowler</option><option>All-rounder</option><option>Wicketkeeper</option></select></div></div><p><button type="submit" disabled={!s}>Register & Pay Online</button></p></form>}</section>
 {s?.upi_id&&<section className="panel"><h2>UPI payment option</h2><p>UPI ID: <b>{s.upi_id}</b></p><p>Payee: {s.payee_name}</p>{qr&&<p><img src={qr} alt="UPI payment QR code" width="220" height="220"/></p>}<a className="button" href={upi}>Open UPI app</a><p className="muted">After manual UPI payment, contact the league admin with your payment reference. Admin verification is required.</p></section>}
 {msg&&<p className="status">{msg}</p>}<p className="muted"><a href="/admin">Admin</a></p></main>;
}