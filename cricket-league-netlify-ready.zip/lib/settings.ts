import { adminDb } from "./supabase";
export async function getSettings(){
 const db=adminDb();
 const {data,error}=await db.from("league_settings").select("*").limit(1).maybeSingle();
 if(error) throw error;
 return data ?? {league_name:"Cricket League",registration_fee:500,upi_id:"",payee_name:"Cricket League",registration_open:true};
}