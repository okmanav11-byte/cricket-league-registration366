create extension if not exists "pgcrypto";
create table if not exists public.league_settings (
 id uuid primary key default gen_random_uuid(),
 league_name text not null default 'Cricket League',
 registration_fee numeric(10,2) not null default 500,
 upi_id text default '',
 payee_name text default 'Cricket League',
 registration_open boolean not null default true,
 updated_at timestamptz not null default now()
);
create table if not exists public.registrations (
 id uuid primary key default gen_random_uuid(),
 full_name text not null,email text not null,phone text not null,
 team_name text,player_role text,city text,
 status text not null default 'pending',
 payment_status text not null default 'pending',
 payment_method text,
 created_at timestamptz not null default now()
);
create table if not exists public.payments (
 id uuid primary key default gen_random_uuid(),
 registration_id uuid not null references public.registrations(id) on delete cascade,
 provider text not null default 'razorpay',
 razorpay_order_id text,razorpay_payment_id text,
 amount numeric(10,2) not null,status text not null default 'pending',
 created_at timestamptz not null default now()
);
alter table public.league_settings enable row level security;
alter table public.registrations enable row level security;
alter table public.payments enable row level security;
insert into public.league_settings(league_name,registration_fee,upi_id,payee_name)
select 'Cricket League',500,'','Cricket League'
where not exists(select 1 from public.league_settings);
create index if not exists registrations_created_at_idx on public.registrations(created_at desc);
create index if not exists payments_registration_id_idx on public.payments(registration_id);